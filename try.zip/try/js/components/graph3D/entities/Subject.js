class Subject {
    constructor( points = [], edges = [], polygons = [] ) {
        this.points = points;
        this.edges = edges;
        this.polygons = polygons;
    }
}