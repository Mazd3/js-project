Template.prototype.headerTemplate = () => `
        <button 
            class="headerButton" 
            data-component="graph2D"
        >Графики 2D</button>
        <button 
            class="headerButton" 
            data-component="graph3D"
        >Графики 3D</button>
        <button 
            class="headerButton" 
            data-component="calculator"
        >Калькулятор</button>
`;